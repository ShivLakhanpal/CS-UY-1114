'''
Shiv Lakhanpal
svl238
hw7q2.py

This code prints out a power table with 5 rows and 10 columns
'''

import math
for i in range(1,5+1):
    for j in range(1,10+1):
        print(int(math.pow(j,i)),end='\t')







