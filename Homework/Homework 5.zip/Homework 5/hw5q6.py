line_of_text = input("Please enter a line of text: ")
char_remove = input("Please enter the character you want to remove: ")
new_line = line_of_text.replace(char_remove,'')

print(new_line)
